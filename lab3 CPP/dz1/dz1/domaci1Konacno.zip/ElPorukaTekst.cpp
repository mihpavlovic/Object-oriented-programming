#include "ElPorukaTekst.h"
